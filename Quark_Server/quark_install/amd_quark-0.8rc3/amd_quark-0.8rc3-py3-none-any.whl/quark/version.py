__version__ = '0.8rc3'
git_version = 'eb6a660'
is_release = True
